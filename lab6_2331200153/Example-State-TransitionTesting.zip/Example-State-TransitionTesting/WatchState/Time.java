package WatchState;

//concrete state class
public class Time implements StateofWatch {

	@Override
	public String set(Watch w1) {
		w1.setCurrentState(w1.getSetHours());
		System.out.println("Dispay Hours:");
		w1.displaySethour();
		return w1.getCurrentState().toString();
	}

	@Override
	public String mode(Watch w1) {
		w1.setCurrentState(w1.getAltimeter());
		System.out.println("Dispay Altemeter");
		w1.displayAltimeter();
		return w1.getCurrentState().toString();
	}

	@Override
	public String toString() {
		return "Time";
	}

}
