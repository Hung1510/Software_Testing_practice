package WatchState;

//state interface
public interface StateofWatch {
	public String set(Watch w1);
	public String mode(Watch w1);

}
