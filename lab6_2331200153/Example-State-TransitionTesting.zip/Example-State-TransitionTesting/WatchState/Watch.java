package WatchState;

//Context Class
public class Watch {
	private StateofWatch Time;
	private StateofWatch SetHours;
	private StateofWatch SetMinutes;
	private StateofWatch Altimeter;
	
	private StateofWatch currentState;
	private int hour;
	private int minute;
	private int alt;
	private String display;
	
	public Watch(int h,int m, int alt)
	{
		Time=new Time();
		SetHours=new SetHours();
		SetMinutes=new SetMinutes();
		Altimeter=new Altimeter();
		
		currentState=Time;
		
		this.alt=alt;
		if((h>=0 && h<=23)&&(m>=0 && m<=59))
		{
		this.hour=h;
		this.minute=m;
		display=this.hour+":"+this.minute;
		}
			else {
				System.out.println("Wrong Set up: Enter Hour: 0-23, Enter Minute: 0-59");
				System.exit(0);
			}
		
		
	}
	public String set()
	{
		return currentState.set(this);
		
	}
	public String mode()
	{
		return currentState.mode(this);
	}
	public StateofWatch getTime() {
		return Time;
	}
	public StateofWatch getSetHours() {
		return SetHours;
	}
	public StateofWatch getSetMinutes() {
		return SetMinutes;
	}
	public StateofWatch getAltimeter() {
		return Altimeter;
	}
	public void setCurrentState(StateofWatch currentState) {
		this.currentState = currentState;
	}
	public StateofWatch getCurrentState() {
		return currentState;
	}
	public void displayTime() {
		
		this.display= this.hour+":"+this.minute;
		
	}
	public void displayAltimeter() {
		this.display="Altimeter: "+this.alt+" meter";
		
	}
	public void add1Hour() {
		
		if(this.hour==23)
		{
		this.hour=0;
		}
		
			else
			this.hour+=1;
			
		
	}
	public void add1Minute() {
		if(minute==59)
		{
			this.hour+=1;
			this.minute=0;
		
				if(this.hour>=24)
				{
					this.hour=this.hour-24;
				}
			
		}
		
			else
			this.minute+=1;
		
	}
	public void displaySethour() {
		this.display= this.hour+" hour";
		
	}
	public void displaySetMinute() {
		this.display= this.minute+" minutes";
		
	}
	public int getHour() {
		return hour;
	}
	public int getMinute() {
		return minute;
	}
	public int getAlt() {
		return alt;
	}
	public String getDisplay() {
		return display;
	}
	
	

}
