package WatchState;

//concrete state class
public class SetHours implements StateofWatch {

	@Override
	public String set(Watch w1) {
		w1.add1Hour();
		System.out.println("Set Hours:");
		w1.displaySethour();
		return w1.getCurrentState().toString();
	}

	@Override
	public String mode(Watch w1) {
		w1.setCurrentState(w1.getSetMinutes());
		System.out.println("Display Minutes:");
		w1.displaySetMinute();
		return w1.getCurrentState().toString();

	}

	@Override
	public String toString() {
		return "SetHours";
	}

}
