package WatchState;

//concrete state class
public class SetMinutes implements StateofWatch {

	@Override
	public String set(Watch w1) {
		w1.add1Minute();
		System.out.println("Set Minutes:");
		w1.displaySetMinute();
		return w1.getCurrentState().toString();
	}

	@Override
	public String mode(Watch w1) {
		w1.setCurrentState(w1.getTime());
		System.out.println("Display Time");
		w1.displayTime();
		return w1.getCurrentState().toString();
	}

	@Override
	public String toString() {
		return "SetMinutes";
	}

}
