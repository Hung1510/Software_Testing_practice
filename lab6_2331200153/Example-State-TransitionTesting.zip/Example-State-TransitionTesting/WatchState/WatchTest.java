package WatchState;

import static org.junit.Assert.assertEquals;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

class WatchTest {
	
	private Watch w;

	@BeforeEach
	void setUp() throws Exception {
		w=new Watch(23,59,3100);
	}

	@Test
	@DisplayName("Time 0 - Set Hours 0 - Set Hours 1")
	void test1() {
		assertAll("Testcase1Result:",
				()->assertEquals("SetHours",w.set()),
				()->assertEquals("23 hour",w.getDisplay()),
				()->assertEquals("SetHours",w.set()),
				()->assertEquals(0,w.getHour())
				);
	}
	
	@Test
	@DisplayName("Time 0 - Set Hours 0 - Set Mins 0 - Set Mins")
	void test2() {
		assertAll("Testcase2Result:",
				()->assertEquals("SetHours",w.set()),
				()->assertEquals("23 hour",w.getDisplay()),
				()->assertEquals("SetMinutes",w.mode()),
				()->assertEquals("59 minutes",w.getDisplay()),
				()->assertEquals("SetMinutes",w.set()),
				()->assertEquals(0,w.getMinute())
				);
	}
	
	@Test
	@DisplayName("Time 0 - Set Hours 0 - Set Mins 0 � Time")
	void test3() {
		assertAll("Testcase1Result:",
				()->assertEquals("SetHours",w.set()),
				()->assertEquals("23 hour",w.getDisplay()),
				()->assertEquals("SetMinutes",w.mode()),
				()->assertEquals("59 minutes",w.getDisplay()),
				()->assertEquals("Time",w.mode()),
				()->assertEquals("23:59",w.getDisplay())
				);
	}
	
	@Test
	@DisplayName("Time 0 � Altimeter- Time2")
	void test4() {
		assertAll("Testcase1Result:",
				()->assertEquals("Altimeter",w.mode()),
				()->assertEquals("Altimeter: 3100 meter",w.getDisplay()),
				()->assertEquals("Time",w.mode()),
				()->assertEquals("23:59",w.getDisplay())
				);
	}
	
	@Test
	@DisplayName("Time 0-Altimeter-Null  (Sneak Path Test Case)")
	void test5() {
		assertAll("Testcase1Result:",
				()->assertEquals("Altimeter",w.mode()),
				()->assertEquals("Altimeter: 3100 meter",w.getDisplay()),
				()->assertThrows(NullPointerException.class,()->{w.set();})
				);
	}

}
