package Invoice;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class InvoiceDao {
	String jdbc_Driver="com.mysql.cj.jdbc.Driver";
	String db_url="jdbc:mysql://localhost/student";
	String User="root";
	String password="password";
	Connection conn=null;
	
	
	
	public void setup_Table()
	{
		try {
			Class.forName(jdbc_Driver);
			conn=DriverManager.getConnection(db_url, User, password);
			 conn.prepareStatement("create table if not exists invoiceTable1 (name varchar(100), value double)").execute();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	public List<Invoice> all()
	{ List<Invoice> allInvoices = new ArrayList<>();

    try {
        PreparedStatement ps = conn.prepareStatement("select * from invoiceTable1");

        ResultSet rs = ps.executeQuery();

        while(rs.next()) {
            String name = rs.getString("name");
            double value = rs.getDouble("value");
            allInvoices.add(new Invoice(name, value));
        }

    } catch (SQLException e) {
        throw new RuntimeException(e);
    } 
        return allInvoices;
    

}
	
	public void save(Invoice inv) {
        try {
            PreparedStatement ps = conn.prepareStatement("insert into invoiceTable1(name, value) values (?,?)");
            ps.setString(1, inv.getCustomer());
            ps.setDouble(2, inv.getAmount());

            ps.execute();

            //conn.commit();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
	
	public void close() {
        try {
            conn.close();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

}
