package Invoice;

import java.util.ArrayList;
import java.util.List;

public class InvoiceFilter {
	List<Invoice> allInvoices=new ArrayList<>();
	 List<Invoice> filtered = new ArrayList<>();

	 public List<Invoice> filter(List<Invoice> all) {
	         this.allInvoices = all;

	        for(Invoice inv : allInvoices) {
	            if(inv.getAmount() < 100.0)
	                filtered.add(inv);
	        }

	        return filtered;

	    }

}
