package Invoice;

public class Invoice {
	String customer;
	double amount;
	
	public Invoice(String customer, double value) {
        this.customer = customer;
        this.amount = value;
    }
	public String getCustomer() {
		return customer;
	}
	public double getAmount() {
		
		return amount;
	}
	 

}
