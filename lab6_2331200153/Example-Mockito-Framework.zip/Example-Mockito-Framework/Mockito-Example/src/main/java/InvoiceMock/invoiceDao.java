package InvoiceMock;

import java.util.List;

	public interface invoiceDao {
	    List<invoice> all();
	}