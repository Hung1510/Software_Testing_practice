package InvoiceMock;

import java.util.ArrayList;
import java.util.List;



public class invoiceFilter {
	public List<invoice> allInvoices=new ArrayList<invoice>();
	public List<invoice> filtered=new ArrayList<invoice>();

	 public List<invoice> filter(List<invoice> all) {
		
	        
	       
	         this.allInvoices = all;

	       

	        for(invoice inv : allInvoices) {
	            if(inv.getAmount() < 100.0)
	                filtered.add(inv);
	        }

	        return filtered;

	    }

}
