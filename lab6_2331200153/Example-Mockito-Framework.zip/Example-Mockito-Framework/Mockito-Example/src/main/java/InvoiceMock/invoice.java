package InvoiceMock;

public class invoice {
	String customer;
	double amount;
	
	public invoice(String customer, double value) {
        this.customer = customer;
        this.amount = value;
    }
	public String getCustomer() {
		return customer;
	}
	public double getAmount() {
		return amount;
	}
	 

}


