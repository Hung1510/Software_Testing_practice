package StudentDB;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.sql.*;

public class StudentDao {
	
	String jdbc_Driver="com.mysql.cj.jdbc.Driver";
	String db_url="jdbc:mysql://localhost/student";
	String User="root";
	String password="password";
	
	Connection conn=null;
	Statement stmt2=null;
	ResultSet rs=null;
	int count1=0;
	PreparedStatement stmt=null;
	List <Student> all=new ArrayList<Student>();
	List <Student> filtered=new ArrayList<Student>();
	
	public void connect()
	{
		try {
			Class.forName(jdbc_Driver);
			conn=DriverManager.getConnection(db_url, User, password);
			conn.prepareStatement("create table if not exists StudentInfo (name varchar(100), id varchar(100), age int)").execute();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		
	}
	
	public void insert(Student s1)
	{
		try {
            PreparedStatement ps = conn.prepareStatement("insert into StudentInfo(name, id, age) values (?,?,?)");
            ps.setString(1, s1.getName());
            ps.setString(2, s1.getStudentID());
            ps.setInt(3, s1.getAge());

            ps.execute();

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
		
		 
		
	}
	
	public List <Student> getStudent() 
	{
		 
		
		try {
		        PreparedStatement ps = conn.prepareStatement("select * from StudentInfo");

		        ResultSet rs = ps.executeQuery();

		        while(rs.next()) {
		            String name = rs.getString(1);
		            String id= rs.getString(2);
		            int age = rs.getInt(3);
		           
		            all.add(new Student(name,id,age));
		        }

		    } catch (SQLException e) {
		        throw new RuntimeException(e);
		    } 
		 return all;
		
	}
	
	public void closedb() 
	{
		
		
		try {
		       conn.close();
		    } catch (SQLException e) {
		        throw new RuntimeException(e);
		    } 
		
	}


}
