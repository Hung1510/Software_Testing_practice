package StudentDB;

public class Student {
	String StudentID;
	String Name;
	int age;
	public Student(String name, String id, int age)
	{
		
		this.Name=name;
		this.StudentID=id;
		this.age=age;
	}

	public String getStudentID() {
		return StudentID;
	}

	public String getName() {
		return Name;
	}

	public int getAge() {
		return age;
	}
}
