package StudentDB;

import java.util.ArrayList;
import java.util.List;

public class StudentAgeFilter {
	public List<Student> all=new ArrayList<Student>();
	public List<Student> filtered=new ArrayList<Student>();

	public List<Student> ageFilter(List<Student> all) {
		this.all = all;
		
		 for(Student s1:all)
		 {
			 if(s1.getAge()<18)
			 {
				 filtered.add(s1);
			 }
		 }
		 return filtered;
	}


}
