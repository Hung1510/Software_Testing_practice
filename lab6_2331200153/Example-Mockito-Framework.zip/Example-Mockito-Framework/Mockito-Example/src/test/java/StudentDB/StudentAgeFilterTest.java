package StudentDB;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;



class StudentAgeFilterTest {
	private StudentDao sd; 
	private StudentAgeFilter saf;
	private Student s1;
	private Student s2;
	private Student s3;
	public List<Student> all;
	public List<Student> filtered;
	
	@Mock
	private StudentDao sd1;
	
	@BeforeEach
	public void setUp() throws Exception {
		sd=new StudentDao();
		MockitoAnnotations.openMocks(this);
		saf=new StudentAgeFilter();
		s1=new Student("Phu","1314",24);
		s2=new Student("Jhon","1315",16);
		s3=new Student("Shelly","1301",22);
		all=new ArrayList<Student>();
		filtered=new ArrayList<Student>();
	}
	@Test
	void testAgeFilter() {
		sd.connect();
		sd.insert(s1);
		sd.insert(s2);
		sd.insert(s3);
		all=sd.getStudent();
		filtered=saf.ageFilter(all);
		assertEquals("Jhon",filtered.get(1).getName());
	}
	@Test
	void testMock() {
		all=Arrays.asList(s1,s2,s3);
		Mockito.when(sd1.getStudent()).thenReturn(all);
		all=sd1.getStudent();
		filtered=saf.ageFilter(all);
		assertEquals("Jhon",filtered.get(0).getName());
	}

}
