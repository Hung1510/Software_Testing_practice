package InvoiceMock;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import java.util.Arrays;


class invoiceFilterTest {
	
	
	private invoiceFilter inf;
    private invoice inv1;
    private invoice inv2;
    private invoice inv3;
    private List<invoice> allInvoices;
    private List<invoice> filtered;
    
    @Mock
    invoiceDao dao;

	@BeforeEach
	void setUp() throws Exception {
		MockitoAnnotations.openMocks(this);
		 inf=new invoiceFilter();
		 inv1=new invoice("abex",96);
		 inv2=new invoice("dfgh",180);
		 inv3=new invoice("gdfr",250);
		 allInvoices=new ArrayList<invoice>();
		 filtered = new ArrayList<invoice>();
	}

	@Test
	void test() {
		allInvoices=Arrays.asList(inv1,inv2,inv3);
		Mockito.when(dao.all()).thenReturn(allInvoices);
		allInvoices=dao.all();
		filtered=inf.filter(allInvoices);
		assertEquals("abex",filtered.get(0).getCustomer());
	}

}
