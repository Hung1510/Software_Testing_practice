package Invoice;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class InvoiceFilterTest {
	private InvoiceDao dao;
	private InvoiceFilter inf;
    private Invoice inv1;
    private Invoice inv2;
    private Invoice inv3;
    private List<Invoice> allInvoices;
    private List<Invoice> filtered;
	@BeforeEach
	void setUp()
	{
	dao=new InvoiceDao();
	inf=new InvoiceFilter();
	inv1=new Invoice("def",500);
	inv2=new Invoice("fgyz",180);
	inv3=new Invoice("tqrs",50);
	allInvoices=new ArrayList<>();
	filtered = new ArrayList<>();
	}
	
	@Test
	void test() {
		dao.setup_Table();
		dao.save(inv1);
		dao.save(inv2);
		dao.save(inv3);
		allInvoices=dao.all();
		filtered=inf.filter(allInvoices);
		assertAll("Resuts",
				()->assertEquals("tqrs",filtered.get(2).getCustomer()),
		()->assertEquals("qrs",filtered.get(1).getCustomer())
		);
	}


}
