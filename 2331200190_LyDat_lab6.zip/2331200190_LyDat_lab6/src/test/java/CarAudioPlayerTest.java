import static org.mockito.Mockito.*;

import CustomerPremium.CustomerPremium.Customer;
import CustomerPremium.CustomerPremium.CustomerDao;
import CustomerPremium.CustomerPremium.CustomerPremium;

import carAudioPlayer.AudioPlayer;
import org.junit.Before;
import org.junit.Test;

import java.util.*;

import static org.junit.Assert.*;

public class CarAudioPlayerTest {
    AudioPlayer player;
    @Before
    public void setUp() {
        List<String> radios = new ArrayList<>();
        radios.add("FM90");
        radios.add("FM99");
        radios.add("FM100");

        List<String> songs = new ArrayList<>();
        songs.add("Song1");
        songs.add("Song2");
        songs.add("Song3");

        player = new AudioPlayer(radios, songs);
    }

    @Test
    public void testRadioNextStation() {
        player.playRadio();
        player.playingNextChannel();
        String result = player.playRadio();
        assertEquals("FM99", result);
    }

    @Test
    public void testRadioRewindStation() {
        player.playRadio();
        player.playingPreviousChannel();
        String result = player.playRadio();
        assertEquals("FM100", result);
    }

    @Test
    public void testRadioToMp3() {
        // first state is radio
        player.mp3();
        assertEquals("MP3 Playing", player.getCurrentState().toString());
    }

    @Test
    public void testMp3NextSong() {
        player.mp3();
        player.playingNextSong();
        String result = player.playMP3Song();
        assertEquals("Song2", result);
    }

    @Test
    public void testMp3PreviousSong() {
        player.mp3();
        player.playingPreviousSong();
        String result = player.playMP3Song();
        assertEquals("Song3", result);
    }

    @Test
    public void testMp3ToRadio() {
        player.mp3();
        player.radio();
        assertEquals("Radio Playing", player.getCurrentState().toString());
    }

    @Test
    public void testTrafficAlertFromRadio() {
        // first state is radio
        player.trafficalert();
        assertEquals("Radio Alerted", player.getCurrentState().toString());
    }

    @Test
    public void testTrafficAlertFromMp3() {
        player.mp3();
        player.trafficalert();

        assertEquals("MP3 Alerted", player.getCurrentState().toString());
    }

    @Test
    public void testTrafficDoneReturnRadio() {
        // first state is radio
        player.trafficalert();
        player.done();

        assertEquals("Radio Playing", player.getCurrentState().toString());
    }

    @Test
    public void testTrafficDoneReturnMp3() {
        player.mp3();
        player.trafficalert();
        player.done();
        assertEquals("MP3 Playing", player.getCurrentState().toString());
    }
}
