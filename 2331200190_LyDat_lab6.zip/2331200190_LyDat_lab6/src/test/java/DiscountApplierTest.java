import static org.mockito.Mockito.*;

import discount.discount.DiscountApplier;
import discount.discount.Product;
import discount.discount.ProductDao;

import org.junit.Before;
import org.junit.Test;

import java.util.*;

import static org.junit.Assert.*;

public class DiscountApplierTest {

    ProductDao dao;
    List<Product> products;
    DiscountApplier applier;

    @Before
    public void setUp() {
        dao = mock(ProductDao.class);

        products = new ArrayList<>();

        products.add(new Product("TV", 100, "HOME"));
        products.add(new Product("Laptop", 100, "BUSINESS"));

        when(dao.all()).thenReturn(products);

        applier = new DiscountApplier(dao);
    }

    @Test
    public void testHomeCategoryDiscount() {
        applier.setNewPrices();
        assertEquals(90, products.get(0).getPrice(), 0.01);
    }

    @Test
    public void testBusinessCategoryIncrease() {
        applier.setNewPrices();
        assertEquals(110, products.get(1).getPrice(), 0.01);
    }
}