import static org.mockito.Mockito.*;

import CustomerPremium.CustomerPremium.Customer;
import CustomerPremium.CustomerPremium.CustomerDao;
import CustomerPremium.CustomerPremium.CustomerPremium;

import org.junit.Before;
import org.junit.Test;

import java.util.*;

import static org.junit.Assert.*;

public class CustomerPremiumTest {

    CustomerDao dao;
    List<Customer> customers;
    CustomerPremium premium;

    @Before
    public void setUp() {
        dao = mock(CustomerDao.class);

        customers = new ArrayList<>();

        customers.add(new Customer("Dat", 4000, 6, 4000, ""));
        customers.add(new Customer("An", 2000, 3, 2000, ""));
        customers.add(new Customer("Binh", 3500, 5, 3500, ""));

        when(dao.all()).thenReturn(customers);

        premium = new CustomerPremium();
    }

    @Test
    public void testPremiumDiscount() {
        premium.PremiumCal(dao.all());
        assertEquals(3200, customers.get(0).getPresentsBill(), 0.01);
        assertEquals(2800, customers.get(2).getPresentsBill(), 0.01);
    }

    @Test
    public void testNonPremiumDiscount() {
        premium.PremiumCal(dao.all());
        assertEquals(2000, customers.get(1).getPresentsBill(), 0.01);
    }
}