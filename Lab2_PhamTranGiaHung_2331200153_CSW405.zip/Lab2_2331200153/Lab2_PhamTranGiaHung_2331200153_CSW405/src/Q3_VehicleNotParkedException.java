/**
 * Exception throw when remove vehicle not in garare
 */
public class Q3_VehicleNotParkedException extends Exception {
    public Q3_VehicleNotParkedException(String message) {
        super(message);
    }
}
