/**
 * Exception throw when no space left
 */
public class Q3_InsufficientSpaceException extends Exception {
    public Q3_InsufficientSpaceException(String message) {
        super(message);
    }
}
