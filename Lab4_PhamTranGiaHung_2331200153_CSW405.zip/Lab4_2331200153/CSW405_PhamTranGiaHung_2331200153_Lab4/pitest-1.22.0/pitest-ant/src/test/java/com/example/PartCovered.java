package com.example;

public class PartCovered {

  public int returnsOneProperlytestedByTest() {
    return 1;
  }

  public int returnsTwoNotCoveredByTest() {
    return 2;
  }

  public int returnsThreeCoveredButNotTestedByTest() {
    return 3;
  }

}
