/*
 * Copyright 2011 Henry Coles
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and limitations under the License.
 */
package org.pitest.testapi;

import java.io.Serializable;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class TestGroupConfig implements Serializable {

  private static final long serialVersionUID = 1L;

  private final List<String> excludedGroups;
  private final List<String> includedGroups;

  public TestGroupConfig(final List<String> excludedGroups,
      final List<String> includedGroups) {
    this.excludedGroups = (excludedGroups != null ? excludedGroups
        : Collections.emptyList());
    this.includedGroups = (includedGroups != null ? includedGroups
        : Collections.emptyList());
  }

  public TestGroupConfig() {
    this(null, null);
  }

  public static TestGroupConfig emptyConfig() {
    return new TestGroupConfig();
  }

  public TestGroupConfig withExcludedGroups(String... excluded) {
    return new TestGroupConfig(Arrays.asList(excluded), this.includedGroups);
  }

  public TestGroupConfig withIncludedGroups(String... included) {
    return new TestGroupConfig(this.excludedGroups, Arrays.asList(included));
  }

  public List<String> getExcludedGroups() {
    return this.excludedGroups;
  }

  public List<String> getIncludedGroups() {
    return this.includedGroups;
  }

  @Override
  public String toString() {
    return "TestGroupConfig [excludedGroups=" + this.excludedGroups
        + ", includedGroups=" + this.includedGroups + "]";
  }

}
