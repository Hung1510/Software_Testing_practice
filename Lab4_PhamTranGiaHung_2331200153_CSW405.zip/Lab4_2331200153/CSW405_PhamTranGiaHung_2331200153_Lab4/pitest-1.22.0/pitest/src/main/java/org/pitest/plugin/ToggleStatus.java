package org.pitest.plugin;

public enum ToggleStatus {
  ACTIVATE, DEACTIVATE
}
