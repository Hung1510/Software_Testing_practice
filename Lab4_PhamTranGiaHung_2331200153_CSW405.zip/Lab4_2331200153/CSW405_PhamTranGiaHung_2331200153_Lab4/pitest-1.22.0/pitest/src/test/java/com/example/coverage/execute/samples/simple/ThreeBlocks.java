package com.example.coverage.execute.samples.simple;

public class ThreeBlocks {
  int foo(int i) {
    if (i > 30) {
      return 1;
    }
    return 2;
  }
}
