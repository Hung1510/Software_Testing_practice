package org.pitest.mutationtest.engine.gregor;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

@Retention(value=RetentionPolicy.CLASS)
public @interface DoNotMutate {

}
