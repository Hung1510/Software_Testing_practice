package org.pitest;

public interface SystemTest {

}
